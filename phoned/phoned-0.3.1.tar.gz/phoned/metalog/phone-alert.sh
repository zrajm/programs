#!/bin/ash
#
# phone-alert - display caller id info for incoming phone calls
#
# [2004-10-17, 05.19-05.50] v0.1 - shamelessy stole code from "ssh-alert.sh"
# (no, wait! - *I* wrote that script as well! - okay, so maybe not *shame-
# lessy*, then) and stripped away a lot of unecessary stuff -- and voila!
#
# This script is intended to be run from metalog.conf -- I use the following
# recipe:
#
#       # [2004-10-17]
#       Caller ID Info Alert :
#            facility = "daemon"
#            program  = "phoned"
#            regex    = "is calling$"
#            command  = "/etc/metalog/phone-alert.sh"
#
# Metalog(1) always passes the following three argumens.
#
#     $1 = time    (e.g. "Oct  7 05:33:07")
#     $2 = program (e.g. "phoned")
#     $3 = message (e.g. "0762115043 is calling")
#
# TODO: Figure out if the current console graphical (running X) and, if so,
# what window manager is in use. Use this info to change the way text is
# displayed, e.g. maybe use xosd instead of "ratpoison -c" when using a more
# graphic oriented wm. (Maybe "write" if on text console?)
#
# "fgconsole" returns currently actuive console's number. "/tmp/.X#-lock"
# contains the PID of the X server running on X display # (it's child is the
# window manager).
#

NOBEEPFILE=/etc/metalog/no_beep                # no sound if this file exists
export XAUTHORITY=/etc/metalog/Xauthority      # needed for "ratpoison -c"
#set -- $3                                      # split $3 into words in $@
#msg="$*"                                       #   just set msg to whatever is

# send message to the first 10 X-displays
for D in 0 1 2 3 4 5 6 7 8 9; do               # for 1 -- 10
    [ -e /tmp/.X${D}-lock ] || continue        #   if X lockfile exists
    ratpoison -d:$D -c "echo $3" &             #     display message in
done                                           #       ratpoison

# DEBUG thingy:
#sudo -u "$user" sh -c "echo '$msg' >/home/$user/.ssh-logins"

